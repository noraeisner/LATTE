void fakec()
{
   return;
}
