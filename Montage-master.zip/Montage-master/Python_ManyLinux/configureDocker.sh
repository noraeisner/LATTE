#!/bin/sh

/opt/python/cp27-cp27m/bin/pip install Cython
/opt/python/cp27-cp27m/bin/pip install jinja2

/opt/python/cp36-cp36m/bin/pip install Cython
/opt/python/cp36-cp36m/bin/pip install jinja2
