#ifndef MBGEXEC_H
#define MBGEXEC_H

int mBgExec_nextImg();
int mBgExec_nextCorr();

#endif
