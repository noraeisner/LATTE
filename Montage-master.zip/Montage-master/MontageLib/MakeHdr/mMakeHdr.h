#ifndef MMAKEHDR_H
#define MMAKEHDR_H

/***************************************/
/* Define mMakeHdr function prototypes */
/***************************************/

int mMakeHdr_stradd      (char *header, char *card);
int mMakeHdr_readTemplate(char *filename);

#endif
