#ifndef MBGEXEC_H
#define MBGEXEC_H

int mArchiveGet_bunzip(char *datafile, int debug);

#endif
